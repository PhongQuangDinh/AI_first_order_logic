criminal(X).
weapon(X).