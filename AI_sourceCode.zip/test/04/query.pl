mother(X,princeCharles).
father(X,princeCharles).