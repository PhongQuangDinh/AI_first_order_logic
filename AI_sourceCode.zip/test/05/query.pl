married(X,jill).
married(jill,X).